from django.contrib import admin

from .models import ProductReview, SellerReview


@admin.register(ProductReview)
class ProductReviewAdmin(admin.ModelAdmin):
    list_display = ("product", "buyer", "rating", "status", "created_at")
    list_filter = ("status", "rating")

@admin.register(SellerReview)
class SellerReviewAdmin(admin.ModelAdmin):
    list_display = ("store", "buyer", "rating", "created_at")
    list_filter = ("rating",)

# Register your models here.
