from django.contrib import admin

from .models import ProductReview


@admin.register(ProductReview)
class ProductReviewAdmin(admin.ModelAdmin):
    list_display = ("product", "buyer", "rating", "status", "created_at")
    list_filter = ("status", "rating")

# Register your models here.
