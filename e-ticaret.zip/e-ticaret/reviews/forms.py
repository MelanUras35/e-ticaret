from django import forms

from .models import SellerReview


class SellerReviewForm(forms.ModelForm):
    rating = forms.ChoiceField(
        choices=[(i, str(i)) for i in range(1, 6)],
        label="Puan",
    )

    class Meta:
        model = SellerReview
        fields = ("rating", "comment")
        widgets = {"comment": forms.Textarea(attrs={"rows": 3, "placeholder": "Yorum yaz..."})}
