from django.urls import path

from . import views

urlpatterns = [
    path("satici/<int:store_id>/yorum/", views.create_seller_review, name="create_seller_review"),
]
