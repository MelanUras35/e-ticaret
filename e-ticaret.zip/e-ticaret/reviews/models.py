from django.db import models
from django.utils import timezone

from accounts.models import User
from marketplace.models import Product, Store
from orders.models import OrderItem


class ProductReview(models.Model):
    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        REMOVED = "REMOVED", "Removed"

    order_item = models.OneToOneField(OrderItem, on_delete=models.CASCADE, related_name="review")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="reviews")
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name="reviews")
    rating = models.PositiveIntegerField()
    comment = models.TextField(blank=True)
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.PENDING)
    seller_reply = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    editable_until = models.DateTimeField(null=True, blank=True)
    moderated_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name="moderated_reviews"
    )
    moderation_reason = models.TextField(blank=True)

    def allow_edit_for_days(self, days: int = 7) -> None:
        self.editable_until = timezone.now() + timezone.timedelta(days=days)
        self.save(update_fields=["editable_until"])

    def __str__(self) -> str:
        return f"Review for {self.product.name}"


class SellerReview(models.Model):
    store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name="reviews")
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name="seller_reviews")
    rating = models.PositiveIntegerField()
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("store", "buyer")

    def __str__(self) -> str:
        return f"Seller review for {self.store.name}"

# Create your models here.
