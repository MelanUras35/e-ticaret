from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect

from marketplace.models import Store
from orders.models import OrderItem

from .forms import SellerReviewForm
from .models import SellerReview


@login_required
def create_seller_review(request, store_id: int):
    store = get_object_or_404(Store, id=store_id, status=Store.Status.ACTIVE)
    has_purchase = OrderItem.objects.filter(order__buyer=request.user, seller=store).exists()
    if not has_purchase:
        return redirect("sellers")
    if request.method != "POST":
        return redirect("sellers")
    form = SellerReviewForm(request.POST)
    if form.is_valid():
        SellerReview.objects.update_or_create(
            store=store,
            buyer=request.user,
            defaults={
                "rating": int(form.cleaned_data["rating"]),
                "comment": form.cleaned_data["comment"],
            },
        )
    return redirect("sellers")
