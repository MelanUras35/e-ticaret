from django.db import models

from accounts.models import User
from orders.models import Order


class OrderThread(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="threads")
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name="buyer_threads")
    seller = models.ForeignKey(User, on_delete=models.CASCADE, related_name="seller_threads")
    created_at = models.DateTimeField(auto_now_add=True)
    is_blocked = models.BooleanField(default=False)
    blocked_reason = models.TextField(blank=True)

    def __str__(self) -> str:
        return f"Thread for Order #{self.order_id}"


class OrderMessage(models.Model):
    thread = models.ForeignKey(OrderThread, on_delete=models.CASCADE, related_name="messages")
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="messages")
    content = models.TextField()
    is_system = models.BooleanField(default=False)
    is_flagged = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f"Message #{self.id} in Thread #{self.thread_id}"


class Conversation(models.Model):
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name="buyer_conversations")
    seller = models.ForeignKey(User, on_delete=models.CASCADE, related_name="seller_conversations")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("buyer", "seller")

    def __str__(self) -> str:
        return f"Conversation #{self.id} ({self.buyer.username} -> {self.seller.username})"


class ConversationMessage(models.Model):
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name="messages")
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="conversation_messages")
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f"Conversation message #{self.id}"

# Create your models here.
