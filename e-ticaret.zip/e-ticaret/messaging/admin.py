from django.contrib import admin

from .models import Conversation, ConversationMessage, OrderMessage, OrderThread


@admin.register(OrderThread)
class OrderThreadAdmin(admin.ModelAdmin):
    list_display = ("order", "buyer", "seller", "created_at", "is_blocked")
    list_filter = ("is_blocked",)


@admin.register(OrderMessage)
class OrderMessageAdmin(admin.ModelAdmin):
    list_display = ("thread", "sender", "is_system", "is_flagged", "created_at")
    list_filter = ("is_system", "is_flagged")

@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ("id", "buyer", "seller", "updated_at")


@admin.register(ConversationMessage)
class ConversationMessageAdmin(admin.ModelAdmin):
    list_display = ("conversation", "sender", "created_at")

# Register your models here.
