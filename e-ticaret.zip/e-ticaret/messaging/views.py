from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render

from accounts.models import User
from marketplace.models import Store

from .forms import ConversationMessageForm
from .models import Conversation, ConversationMessage


def _is_participant(conversation: Conversation, user: User) -> bool:
    return conversation.buyer_id == user.id or conversation.seller_id == user.id


@login_required
def inbox(request):
    conversations = (
        Conversation.objects.filter(Q(buyer=request.user) | Q(seller=request.user))
        .select_related("buyer", "seller")
        .order_by("-updated_at")
    )
    return render(request, "messaging/inbox.html", {"conversations": conversations})


@login_required
def start_conversation(request, store_id: int):
    store = get_object_or_404(Store, id=store_id, status=Store.Status.ACTIVE)
    seller = store.owner
    if seller.id == request.user.id:
        return redirect("inbox")
    conversation, _created = Conversation.objects.get_or_create(buyer=request.user, seller=seller)
    return redirect("conversation_detail", conversation_id=conversation.id)


@login_required
def conversation_detail(request, conversation_id: int):
    conversation = get_object_or_404(Conversation.objects.select_related("buyer", "seller"), id=conversation_id)
    if not _is_participant(conversation, request.user):
        return redirect("inbox")

    if request.method == "POST":
        form = ConversationMessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.conversation = conversation
            message.sender = request.user
            message.save()
            Conversation.objects.filter(id=conversation.id).update(updated_at=message.created_at)
            return redirect("conversation_detail", conversation_id=conversation.id)
    else:
        form = ConversationMessageForm()

    messages = conversation.messages.select_related("sender").order_by("created_at")
    return render(
        request,
        "messaging/conversation_detail.html",
        {"conversation": conversation, "messages": messages, "form": form},
    )
