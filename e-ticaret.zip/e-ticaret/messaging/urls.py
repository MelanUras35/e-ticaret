from django.urls import path

from . import views

urlpatterns = [
    path("mesajlar/", views.inbox, name="inbox"),
    path("mesajlar/baslat/<int:store_id>/", views.start_conversation, name="start_conversation"),
    path("mesajlar/<int:conversation_id>/", views.conversation_detail, name="conversation_detail"),
]
