from django import forms

from .models import Store


class SellerApplyForm(forms.ModelForm):
    class Meta:
        model = Store
        fields = ("name", "company_name", "products_offered", "description", "region_restrictions", "allows_18_plus")
        widgets = {
            "description": forms.Textarea(attrs={"rows": 4}),
        }


class ProductCreateForm(forms.Form):
    name = forms.CharField(max_length=200)
    category = forms.CharField(max_length=120)
    price = forms.DecimalField(max_digits=12, decimal_places=2)
    description = forms.CharField(widget=forms.Textarea(attrs={"rows": 4}), required=False)
    image_url = forms.URLField(required=False)
