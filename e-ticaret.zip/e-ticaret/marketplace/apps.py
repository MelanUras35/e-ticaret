from django.apps import AppConfig


class MarketplaceConfig(AppConfig):
    name = 'marketplace'
