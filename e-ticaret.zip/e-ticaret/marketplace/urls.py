from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("katalog/", views.catalog, name="catalog"),
    path("saticilar/", views.sellers, name="sellers"),
    path("urun/<int:product_id>/", views.product_detail, name="product_detail"),
    path("yonetim/", views.admin_panel, name="admin_panel"),
    path("yonetim/satici/<int:store_id>/onay/", views.approve_seller, name="approve_seller"),
    path("yonetim/satici/<int:store_id>/red/", views.reject_seller, name="reject_seller"),
    path("yonetim/talep/<int:request_id>/onay/", views.approve_seller_request, name="approve_seller_request"),
    path("yonetim/talep/<int:request_id>/red/", views.reject_seller_request, name="reject_seller_request"),
    path("kategoriler/", views.categories, name="categories"),
    path("kampanyalar/", views.campaigns, name="campaigns"),
    path("satici-ol/", views.seller_apply, name="seller_apply"),
    path("satici/urun-ekle/", views.seller_add_product, name="seller_add_product"),
    path("destek/", views.support, name="support"),
]
