from django.db import models
from django.utils import timezone

from accounts.models import User


class Category(models.Model):
    name = models.CharField(max_length=120, unique=True)
    slug = models.SlugField(max_length=140, unique=True)
    is_active = models.BooleanField(default=True)

    def __str__(self) -> str:
        return self.name


class Store(models.Model):
    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        ACTIVE = "ACTIVE", "Active"
        SUSPENDED = "SUSPENDED", "Suspended"
        UNDER_REVIEW = "UNDER_REVIEW", "Under review"
        REJECTED = "REJECTED", "Rejected"

    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="stores")
    name = models.CharField(max_length=150)
    company_name = models.CharField(max_length=150, blank=True)
    description = models.TextField(blank=True)
    products_offered = models.CharField(max_length=255, blank=True)
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.PENDING)
    region_restrictions = models.CharField(max_length=255, blank=True)
    allows_18_plus = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return self.name


class StoreUpdateRequest(models.Model):
    store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name="update_requests")
    requested_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name="store_update_requests")
    payload = models.JSONField(default=dict)
    status = models.CharField(
        max_length=16,
        choices=[("PENDING", "Pending"), ("APPROVED", "Approved"), ("REJECTED", "Rejected")],
        default="PENDING",
    )
    reviewed_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name="reviewed_store_updates"
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)

    def approve(self, reviewer: User) -> None:
        self.status = "APPROVED"
        self.reviewed_by = reviewer
        self.reviewed_at = timezone.now()
        self.save(update_fields=["status", "reviewed_by", "reviewed_at"])

    def __str__(self) -> str:
        return f"Store update for {self.store.name}"


class Product(models.Model):
    store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name="products")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, related_name="products")
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    base_price = models.DecimalField(max_digits=12, decimal_places=2)
    is_active = models.BooleanField(default=True)
    is_preorder = models.BooleanField(default=False)
    preorder_available_on = models.DateField(null=True, blank=True)
    is_bundle = models.BooleanField(default=False)
    min_age = models.PositiveIntegerField(default=0)
    restricted_regions = models.CharField(max_length=255, blank=True)
    max_per_order = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return self.name


class ProductVariant(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="variants")
    name = models.CharField(max_length=120)
    sku = models.CharField(max_length=64, unique=True)
    price = models.DecimalField(max_digits=12, decimal_places=2)
    stock = models.PositiveIntegerField(default=0)
    reserved_stock = models.PositiveIntegerField(default=0)

    def available_stock(self) -> int:
        return max(self.stock - self.reserved_stock, 0)

    def __str__(self) -> str:
        return f"{self.product.name} - {self.name}"


class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="images")
    image_url = models.URLField()
    is_primary = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f"Image for {self.product.name}"


class ProductBundleItem(models.Model):
    bundle = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="bundle_items")
    item = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="bundled_in")
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self) -> str:
        return f"{self.bundle.name} includes {self.item.name}"

# Create your models here.
