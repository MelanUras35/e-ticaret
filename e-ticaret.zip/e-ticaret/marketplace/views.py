import random
from decimal import Decimal, ROUND_HALF_UP

from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.utils.text import slugify
from django.utils.crypto import get_random_string

from accounts.models import SellerAccessRequest, SellerAllowlist, SellerProfile, User
from promotions.models import SellerDiscount
from reports.models import UserReport
from .forms import ProductCreateForm, SellerAccessRequestForm, SellerApplyForm
from .models import Product, ProductImage, Store
from orders.models import OrderItem
from marketplace.models import Category


def home(request):
    _ensure_demo_products()
    products = list(
        Product.objects.select_related("store", "category")
        .prefetch_related("images", "variants")
        .filter(is_active=True)
        .order_by("-created_at")[:12]
    )
    _apply_discounts(products)
    live_stats = {
        "orders": random.randint(180, 680),
        "return_rate": f"%{random.uniform(1.2, 4.8):.1f}",
        "risky_sellers": random.randint(1, 9),
    }
    featured_demo = [
        {
            "name": "Akilli Telefon Pro",
            "category": "Elektronik",
            "price": "18.499",
            "price_value": Decimal("18499"),
            "seller": "TeknoNet",
            "image_url": "marketplace/images/phone.svg",
            "discount_percent": 10,
        },
        {
            "name": "No-Frost Buzdolabi",
            "category": "Beyaz Esya",
            "price": "24.900",
            "price_value": Decimal("24900"),
            "seller": "BeyazYap",
            "image_url": "marketplace/images/fridge.svg",
            "discount_percent": 0,
        },
        {
            "name": "Kablosuz Kulaklik",
            "category": "Elektronik",
            "price": "4.250",
            "price_value": Decimal("4250"),
            "seller": "SoundBox",
            "image_url": "marketplace/images/headphones.svg",
            "discount_percent": 15,
        },
        {
            "name": "Robot Supurge",
            "category": "Beyaz Esya",
            "price": "12.990",
            "price_value": Decimal("12990"),
            "seller": "Evim360",
            "image_url": "marketplace/images/robot-vacuum.svg",
            "discount_percent": 0,
        },
        {
            "name": "Ahşap Çalışma Masası",
            "category": "Ev Eşyası",
            "price": "3.450",
            "price_value": Decimal("3450"),
            "seller": "DekorLine",
            "image_url": "https://source.unsplash.com/featured/640x420?wooden-desk",
            "discount_percent": 20,
        },
        {
            "name": "Vintage Kitap Seti",
            "category": "Kitap",
            "price": "850",
            "price_value": Decimal("850"),
            "seller": "KampusKitap",
            "image_url": "marketplace/images/books.svg",
            "discount_percent": 0,
        },
        {
            "name": "Ergonomik Sandalye",
            "category": "Ev Eşyası",
            "price": "2.700",
            "price_value": Decimal("2700"),
            "seller": "DekorLine",
            "image_url": "marketplace/images/chair.svg",
            "discount_percent": 5,
        },
        {
            "name": "Koleksiyon Oyuncak",
            "category": "Oyuncak",
            "price": "1.150",
            "price_value": Decimal("1150"),
            "seller": "ToyBox",
            "image_url": "marketplace/images/toy.svg",
            "discount_percent": 0,
        },
    ]
    for item in featured_demo:
        if item["discount_percent"]:
            discounted = _apply_discount_price(item["price_value"], item["discount_percent"])
            item["discounted_price"] = f"{discounted:,.2f}".replace(",", ".")
        else:
            item["discounted_price"] = ""
    category_spotlight = _build_category_spotlight(products, featured_demo)
    context = {
        "products": products,
        "live_stats": live_stats,
        "featured_demo": featured_demo,
        "category_spotlight_electronics": category_spotlight.get("Elektronik", []),
        "category_spotlight_whitegoods": category_spotlight.get("Beyaz Esya", []),
        "category_spotlight_home": category_spotlight.get("Ev Eşyası", []),
        "category_spotlight_outdoor": category_spotlight.get("Outdoor", []),
    }
    return render(request, "marketplace/home.html", context)


def _apply_discount_price(price: Decimal, percent: int) -> Decimal:
    return (price * (Decimal("100") - Decimal(percent)) / Decimal("100")).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )


def _apply_discounts(products: list[Product]) -> None:
    if not products:
        return
    now = timezone.now()
    store_ids = {product.store_id for product in products}
    product_ids = {product.id for product in products}
    discounts = SellerDiscount.objects.filter(
        starts_at__lte=now,
        ends_at__gte=now,
    ).filter(Q(product_id__in=product_ids) | Q(product__isnull=True, store_id__in=store_ids))
    product_discounts: dict[int, int] = {}
    store_discounts: dict[int, int] = {}
    for discount in discounts:
        if discount.product_id:
            product_discounts[discount.product_id] = max(
                product_discounts.get(discount.product_id, 0), discount.percent
            )
        else:
            store_discounts[discount.store_id] = max(
                store_discounts.get(discount.store_id, 0), discount.percent
            )
    for product in products:
        percent = product_discounts.get(product.id) or store_discounts.get(product.store_id, 0)
        product.discount_percent = percent
        if percent:
            product.discounted_price = _apply_discount_price(product.base_price, percent)
        else:
            product.discounted_price = None


def _build_category_spotlight(products: list[Product], demo_items: list[dict]) -> dict:
    spotlight = {}
    for product in products:
        if not product.category:
            continue
        spotlight.setdefault(product.category.name, [])
        if len(spotlight[product.category.name]) < 2:
            spotlight[product.category.name].append(product.name)
    for item in demo_items:
        spotlight.setdefault(item["category"], [])
        if len(spotlight[item["category"]]) < 2:
            spotlight[item["category"]].append(item["name"])
    return spotlight


def _get_or_create_category(name: str) -> Category:
    base_slug = slugify(name)
    if not base_slug:
        base_slug = get_random_string(6)
    category = Category.objects.filter(slug=base_slug).first()
    if category:
        return category
    try:
        return Category.objects.create(name=name, slug=base_slug)
    except Exception:
        unique_slug = f"{base_slug}-{get_random_string(4)}"
        return Category.objects.create(name=name, slug=unique_slug)


def _ensure_default_categories() -> dict[str, str]:
    defaults = [
        ("Elektronik", "Telefon, bilgisayar, TV ve aksesuarlar."),
        ("Moda & Aksesuar", "Giyim, ayakkabi, canta ve aksesuarlar."),
        ("Beyaz Esya", "Buzdolabi, camasir, bulasik makineleri."),
        ("Ev & Yasam", "Dekorasyon, tekstil ve ev aksesuarlar."),
        ("Mobilya", "Oturma odasi, yatak odasi ve ofis mobilyalari."),
        ("Mutfak & Sofra", "Kucuk ev aletleri ve mutfak gerecleri."),
        ("Spor & Outdoor", "Kamp, fitness ve outdoor ekipmanlari."),
        ("Oyuncak & Bebek", "Oyuncaklar ve bebek urunleri."),
        ("Kitap & Kirtasiye", "Kitaplar, okul ve ofis urunleri."),
        ("Kozmetik & Kisisel Bakim", "Cilt bakim, sac bakim, parfum."),
        ("Saglik", "Saglik urunleri ve takviyeler."),
        ("Gida & Market", "Gida, icecek ve temel tuketim."),
        ("Evcil Hayvan", "Mama, oyuncak ve pet aksesuarlari."),
        ("Oto & Aksesuar", "Arac bakim ve aksesuarlar."),
        ("Bahce & DIY", "Bahce, tamir ve hobi malzemeleri."),
        ("Bilgisayar & Ofis", "Bilgisayar, yazici ve ofis aksesuar."),
        ("Oyun & Konsol", "Konsollar, oyunlar ve aksesuarlar."),
        ("Muzik & Enstruman", "Enstrumanlar ve muzik ekipmanlari."),
    ]
    for name, _desc in defaults:
        _get_or_create_category(name)
    return {name: desc for name, desc in defaults}


def _ensure_demo_products() -> None:
    demo_stores = [
        (
            "TeknoNet",
            "Teknoloji ve akilli cihazlarda guvenilir satici.",
            [
                ("Akilli Telefon Pro", "Elektronik", Decimal("18499"), "marketplace/images/phone.svg"),
                ("Gaming Laptop 16", "Elektronik", Decimal("42900"), "marketplace/images/laptop.svg"),
                ("Akilli Saat X", "Elektronik", Decimal("7990"), "marketplace/images/smartwatch.svg"),
                ("Akilli TV 55\"", "Elektronik", Decimal("28500"), "marketplace/images/tv.svg"),
                ("Tablet Air 11", "Elektronik", Decimal("15900"), "marketplace/images/phone.svg"),
                ("Kablosuz Hoparlor", "Elektronik", Decimal("3290"), "marketplace/images/headphones.svg"),
            ],
        ),
        (
            "BeyazYap",
            "Beyaz esyada hizli kurulum ve servis.",
            [
                ("No-Frost Buzdolabi", "Beyaz Esya", Decimal("24900"), "marketplace/images/fridge.svg"),
                ("Camasir Makinesi 9kg", "Beyaz Esya", Decimal("19800"), "marketplace/images/washing-machine.svg"),
                ("Airfryer 5L", "Beyaz Esya", Decimal("3900"), "marketplace/images/airfryer.svg"),
                ("Bulasik Makinesi 6 Program", "Beyaz Esya", Decimal("17600"), "marketplace/images/airfryer.svg"),
            ],
        ),
        (
            "DekorLine",
            "Ev esyasi ve mobilyada yeni sezon urunler.",
            [
                ("Ahşap Çalışma Masası", "Ev Eşyası", Decimal("3450"), "https://source.unsplash.com/featured/640x420?wooden-desk"),
                ("Ergonomik Sandalye", "Ev Eşyası", Decimal("2700"), "marketplace/images/chair.svg"),
                ("Kahve Makinesi", "Ev Eşyası", Decimal("2150"), "marketplace/images/coffee-machine.svg"),
                ("Lambader Minimal", "Ev Eşyası", Decimal("1250"), "marketplace/images/desk.svg"),
                ("Salon Konsolu", "Ev Eşyası", Decimal("8950"), "marketplace/images/desk.svg"),
            ],
        ),
        (
            "KampusKitap",
            "Koleksiyon ve kampus kitaplari.",
            [
                ("Vintage Kitap Seti", "Kitap", Decimal("850"), "marketplace/images/books.svg"),
                ("Bilimkurgu Seri Seti", "Kitap", Decimal("1240"), "marketplace/images/books.svg"),
                ("Kisisel Gelisim Seti", "Kitap", Decimal("980"), "marketplace/images/books.svg"),
            ],
        ),
        (
            "ToyBox",
            "Oyuncak ve hobi urunleri.",
            [
                ("Koleksiyon Oyuncak", "Oyuncak", Decimal("1150"), "marketplace/images/toy.svg"),
                ("Ahcap Blok Seti", "Oyuncak", Decimal("540"), "marketplace/images/toy.svg"),
                ("Masaustu Oyun", "Oyuncak", Decimal("720"), "marketplace/images/toy.svg"),
            ],
        ),
        (
            "Outdoorist",
            "Dis mekan ve kamp urunleri.",
            [
                ("Kamp Termosu", "Outdoor", Decimal("780"), "marketplace/images/thermos.svg"),
                ("Kamp Sandalyesi", "Outdoor", Decimal("640"), "marketplace/images/chair.svg"),
                ("Sirt Cantasi 40L", "Outdoor", Decimal("1290"), "marketplace/images/desk.svg"),
            ],
        ),
        (
            "ModaNova",
            "Giyimde gunluk ve trend urunler.",
            [
                ("Oversize Sweat", "Moda", Decimal("1290"), "marketplace/images/desk.svg"),
                ("Klasik Ayakkabı", "Moda", Decimal("1890"), "https://source.unsplash.com/featured/640x420?sneakers,shoes"),
                ("Basic Tisort", "Moda", Decimal("420"), "marketplace/images/desk.svg"),
                ("Denim Ceket", "Moda", Decimal("1490"), "marketplace/images/desk.svg"),
            ],
        ),
        (
            "PetClub",
            "Evcil hayvan urunleri ve aksesuarlar.",
            [
                ("Kedi Oyun Seti", "Pet", Decimal("690"), "marketplace/images/toy.svg"),
                ("Kopek Tasmasi", "Pet", Decimal("420"), "marketplace/images/toy.svg"),
                ("Kedi Kum Kabı", "Pet", Decimal("590"), "marketplace/images/toy.svg"),
                ("Mama Kabı Set", "Pet", Decimal("260"), "marketplace/images/toy.svg"),
            ],
        ),
        (
            "OfisPro",
            "Ofis ve kirtasiye urunleri.",
            [
                ("Not Defteri Seti", "Kirtasiye", Decimal("180"), "marketplace/images/books.svg"),
                ("Kalem Seti", "Kirtasiye", Decimal("220"), "marketplace/images/books.svg"),
                ("Masa Duzenleyici", "Kirtasiye", Decimal("360"), "marketplace/images/desk.svg"),
            ],
        ),
    ]
    for index, (store_name, store_desc, items) in enumerate(demo_stores, start=1):
        demo_seller, _created = User.objects.get_or_create(
            username=f"demo_seller_{index}",
            defaults={"role": User.Role.SELLER},
        )
        store, _created = Store.objects.get_or_create(
            owner=demo_seller,
            name=store_name,
            defaults={
                "description": store_desc,
                "status": Store.Status.ACTIVE,
            },
        )
        for name, category_name, price, image_url in items:
            category = _get_or_create_category(category_name)
            product = Product.objects.filter(store=store, name=name).first()
            if product:
                product.category = category
                product.base_price = price
                product.is_active = True
                product.save(update_fields=["category", "base_price", "is_active"])
            else:
                product = Product.objects.create(
                    store=store,
                    category=category,
                    name=name,
                    description=f"{name} icin demo aciklama.",
                    base_price=price,
                    is_active=True,
                )
            if image_url:
                image_url_final = image_url if image_url.startswith("http") else f"/static/{image_url}"
                image = ProductImage.objects.filter(product=product).first()
                if image:
                    image.image_url = image_url_final
                    image.is_primary = True
                    image.save(update_fields=["image_url", "is_primary"])
                else:
                    ProductImage.objects.create(
                        product=product, image_url=image_url_final, is_primary=True
                    )

    Product.objects.filter(name="Ahcap Calisma Masasi").update(name="Ahşap Çalışma Masası")
    Product.objects.filter(name="Klasik Sneaker").update(name="Klasik Ayakkabı")
    for name, image_url in [
        ("Ahşap Çalışma Masası", "https://source.unsplash.com/featured/640x420?wooden-desk"),
        ("Klasik Ayakkabı", "https://source.unsplash.com/featured/640x420?sneakers,shoes"),
    ]:
        product = Product.objects.filter(name=name).first()
        if not product:
            continue
        image = ProductImage.objects.filter(product=product).first()
        if image:
            image.image_url = image_url
            image.is_primary = True
            image.save(update_fields=["image_url", "is_primary"])
        else:
            ProductImage.objects.create(product=product, image_url=image_url, is_primary=True)


def catalog(request):
    query = request.GET.get("q", "").strip()
    selected_category = request.GET.get("category", "").strip()
    sort = request.GET.get("sort", "new").strip()
    mine_param = request.GET.get("mine", "").strip()
    mine_only = mine_param == "1"
    _ensure_demo_products()
    products = list(
        Product.objects.select_related("store", "category")
        .prefetch_related("images", "variants")
        .filter(is_active=True)
    )
    if mine_only:
        store = Store.objects.filter(owner=request.user).first()
        if store:
            products = [product for product in products if product.store_id == store.id]
        else:
            products = []
    if query:
        products = [product for product in products if query.lower() in product.name.lower()]
    if selected_category:
        products = [product for product in products if product.category and product.category.slug == selected_category]
    if sort == "price_asc":
        products = sorted(products, key=lambda p: p.base_price)
    elif sort == "price_desc":
        products = sorted(products, key=lambda p: p.base_price, reverse=True)
    else:
        products = sorted(products, key=lambda p: p.created_at, reverse=True)
    _apply_discounts(products)
    demo_items = [
        {
            "name": "Akilli Telefon Pro",
            "category": "Elektronik",
            "price": "18.499",
            "price_value": Decimal("18499"),
            "seller": "TeknoNet",
            "image_class": "media-electronics",
            "image_url": "marketplace/images/phone.svg",
            "discount_percent": 10,
        },
        {
            "name": "No-Frost Buzdolabi",
            "category": "Beyaz Esya",
            "price": "24.900",
            "price_value": Decimal("24900"),
            "seller": "BeyazYap",
            "image_class": "media-whitegoods",
            "image_url": "marketplace/images/fridge.svg",
            "discount_percent": 0,
        },
        {
            "name": "Kablosuz Kulaklik",
            "category": "Elektronik",
            "price": "4.250",
            "price_value": Decimal("4250"),
            "seller": "SoundBox",
            "image_class": "media-electronics",
            "image_url": "marketplace/images/headphones.svg",
            "discount_percent": 15,
        },
        {
            "name": "Robot Supurge",
            "category": "Beyaz Esya",
            "price": "12.990",
            "price_value": Decimal("12990"),
            "seller": "Evim360",
            "image_class": "media-whitegoods",
            "image_url": "marketplace/images/robot-vacuum.svg",
            "discount_percent": 0,
        },
        {
            "name": "Ahcap Calisma Masasi",
            "category": "Ev Eşyası",
            "price": "3.450",
            "price_value": Decimal("3450"),
            "seller": "DekorLine",
            "image_class": "media-home",
            "image_url": "marketplace/images/desk.svg",
            "discount_percent": 20,
        },
        {
            "name": "Vintage Kitap Seti",
            "category": "Kitap",
            "price": "850",
            "price_value": Decimal("850"),
            "seller": "KampusKitap",
            "image_class": "media-books",
            "image_url": "marketplace/images/books.svg",
            "discount_percent": 0,
        },
        {
            "name": "Ergonomik Sandalye",
            "category": "Ev Eşyası",
            "price": "2.700",
            "price_value": Decimal("2700"),
            "seller": "DekorLine",
            "image_class": "media-home",
            "image_url": "marketplace/images/chair.svg",
            "discount_percent": 5,
        },
        {
            "name": "Koleksiyon Oyuncak",
            "category": "Oyuncak",
            "price": "1.150",
            "price_value": Decimal("1150"),
            "seller": "ToyBox",
            "image_class": "media-toys",
            "image_url": "marketplace/images/toy.svg",
            "discount_percent": 0,
        },
        {
            "name": "Gaming Laptop 16",
            "category": "Elektronik",
            "price": "42.900",
            "price_value": Decimal("42900"),
            "seller": "GameTek",
            "image_class": "media-electronics",
            "image_url": "marketplace/images/laptop.svg",
            "discount_percent": 8,
        },
        {
            "name": "Akilli Saat X",
            "category": "Elektronik",
            "price": "7.990",
            "price_value": Decimal("7990"),
            "seller": "PulseWear",
            "image_class": "media-electronics",
            "image_url": "marketplace/images/smartwatch.svg",
            "discount_percent": 0,
        },
        {
            "name": "Camasir Makinesi 9kg",
            "category": "Beyaz Esya",
            "price": "19.800",
            "price_value": Decimal("19800"),
            "seller": "BeyazYap",
            "image_class": "media-whitegoods",
            "image_url": "marketplace/images/washing-machine.svg",
            "discount_percent": 12,
        },
        {
            "name": "Kahve Makinesi",
            "category": "Ev Eşyası",
            "price": "2.150",
            "price_value": Decimal("2150"),
            "seller": "KahveLab",
            "image_class": "media-home",
            "image_url": "marketplace/images/coffee-machine.svg",
            "discount_percent": 0,
        },
        {
            "name": "Kamp Termosu",
            "category": "Outdoor",
            "price": "780",
            "price_value": Decimal("780"),
            "seller": "Outdoorist",
            "image_class": "media-home",
            "image_url": "marketplace/images/thermos.svg",
            "discount_percent": 0,
        },
        {
            "name": "Akilli TV 55\"",
            "category": "Elektronik",
            "price": "28.500",
            "price_value": Decimal("28500"),
            "seller": "TeknoNet",
            "image_class": "media-electronics",
            "image_url": "marketplace/images/tv.svg",
            "discount_percent": 10,
        },
        {
            "name": "Airfryer 5L",
            "category": "Beyaz Esya",
            "price": "3.900",
            "price_value": Decimal("3900"),
            "seller": "MutfakPro",
            "image_class": "media-whitegoods",
            "image_url": "marketplace/images/airfryer.svg",
            "discount_percent": 0,
        },
    ]
    for item in demo_items:
        if item["discount_percent"]:
            discounted = _apply_discount_price(item["price_value"], item["discount_percent"])
            item["discounted_price"] = f"{discounted:,.2f}".replace(",", ".")
        else:
            item["discounted_price"] = ""
    use_demo = not products and not mine_only
    demo_categories = sorted({item["category"] for item in demo_items})
    if use_demo:
        if query:
            demo_items = [item for item in demo_items if query.lower() in item["name"].lower()]
        if selected_category:
            demo_items = [item for item in demo_items if item["category"] == selected_category]
    categories = Category.objects.filter(is_active=True).order_by("name")
    return render(
        request,
        "marketplace/catalog.html",
        {
            "products": products,
            "demo_items": demo_items,
            "use_demo": use_demo,
            "categories": categories,
            "demo_categories": demo_categories,
            "query": query,
            "selected_category": selected_category,
            "sort": sort,
            "mine_only": mine_only,
        },
    )


def sellers(request):
    stores = (
        Store.objects.filter(status=Store.Status.ACTIVE)
        .select_related("owner")
        .prefetch_related("reviews")
        .order_by("name")
    )
    purchased_store_ids = set()
    if request.user.is_authenticated:
        purchased_store_ids = set(
            OrderItem.objects.filter(order__buyer=request.user).values_list("seller_id", flat=True)
        )
    demo_names = [
        "KuzeyTech",
        "AnadoluCasa",
        "MaviKutu",
        "PeraDesign",
        "SahilMarket",
        "NovaHome",
        "ZenitStore",
        "EfsunModa",
        "ArvenShop",
        "AtlasPlus",
    ]
    demo_desc = [
        "Elektronik ve ev teknolojilerinde garantili urunler.",
        "Ev esyasi ve dekorasyon odakli yeni koleksiyonlar.",
        "Kucuk mutfak aletleri ve gunluk ihtiyaclar.",
        "Sade tasarimli mobilya ve aksesuar secimleri.",
        "Kampanyali gunluk urunler ve hizli kargo.",
        "Beyaz esyada premium secenekler.",
        "Minimalist ve fonksiyonel urunler.",
        "Moda ve yasam stili odakli secili urunler.",
    ]
    demo_sellers = []
    for name in random.sample(demo_names, k=8):
        demo_sellers.append(
            {
                "name": name,
                "description": random.choice(demo_desc),
            }
        )
    return render(
        request,
        "marketplace/sellers.html",
        {"stores": stores, "demo_sellers": demo_sellers, "purchased_store_ids": purchased_store_ids},
    )


def product_detail(request, product_id: int):
    product = get_object_or_404(
        Product.objects.select_related("store", "category").prefetch_related("images", "variants"),
        id=product_id,
        is_active=True,
    )
    return render(request, "marketplace/product_detail.html", {"product": product})


def _is_admin(user: User) -> bool:
    return user.is_authenticated and (user.is_staff or user.role == User.Role.ADMIN)


@login_required
def admin_panel(request):
    if not _is_admin(request.user):
        return redirect("home")
    pending_stores = Store.objects.filter(status=Store.Status.PENDING).select_related("owner")
    pending_requests = SellerAccessRequest.objects.filter(status=SellerAccessRequest.Status.PENDING).select_related(
        "user"
    )
    pending_reports = (
        UserReport.objects.filter(status=UserReport.Status.PENDING)
        .select_related("reporter", "reported_user", "reported_store", "reported_product", "reviewed_by")
        .order_by("-created_at")
    )
    return render(
        request,
        "marketplace/admin_panel.html",
        {"pending_stores": pending_stores, "pending_requests": pending_requests, "pending_reports": pending_reports},
    )


@login_required
def approve_seller(request, store_id: int):
    if request.method != "POST" or not _is_admin(request.user):
        return redirect("home")
    store = get_object_or_404(Store, id=store_id)
    store.status = Store.Status.ACTIVE
    store.save(update_fields=["status"])
    SellerProfile.objects.update_or_create(
        user=store.owner,
        defaults={
            "store_name": store.name,
            "store_description": store.description,
            "status": SellerProfile.Status.APPROVED,
        },
    )
    return redirect("admin_panel")


@login_required
def reject_seller(request, store_id: int):
    if request.method != "POST" or not _is_admin(request.user):
        return redirect("home")
    store = get_object_or_404(Store, id=store_id)
    store.status = Store.Status.REJECTED
    store.save(update_fields=["status"])
    SellerProfile.objects.update_or_create(
        user=store.owner,
        defaults={
            "store_name": store.name,
            "store_description": store.description,
            "status": SellerProfile.Status.REJECTED,
        },
    )
    return redirect("admin_panel")


@login_required
def approve_seller_request(request, request_id: int):
    if request.method != "POST" or not _is_admin(request.user):
        return redirect("home")
    req = get_object_or_404(SellerAccessRequest, id=request_id)
    identifier = req.user.email or req.user.username
    SellerAllowlist.objects.get_or_create(identifier=identifier, defaults={"note": "Admin onayi"})
    req.status = SellerAccessRequest.Status.APPROVED
    req.save(update_fields=["status"])
    return redirect("admin_panel")


@login_required
def reject_seller_request(request, request_id: int):
    if request.method != "POST" or not _is_admin(request.user):
        return redirect("home")
    req = get_object_or_404(SellerAccessRequest, id=request_id)
    req.status = SellerAccessRequest.Status.REJECTED
    req.save(update_fields=["status"])
    return redirect("admin_panel")


@login_required
def categories(request):
    description_map = _ensure_default_categories()
    categories = Category.objects.filter(is_active=True).order_by("name")
    category_cards = [
        {
            "name": category.name,
            "slug": category.slug,
            "description": description_map.get(category.name, "Bu kategorideki urunleri kesfet."),
        }
        for category in categories
    ]
    return render(request, "marketplace/categories.html", {"category_cards": category_cards})


@login_required
def campaigns(request):
    pool = [
        {"title": "Elektronik %15", "desc": "Akilli urunlerde sinirli sure indirim."},
        {"title": "Ev & Yasam %20", "desc": "Dekor ve mutfak urunlerinde haftasonu firsati."},
        {"title": "Moda 2 Al 1 Ode", "desc": "Secili kiyafetlerde ekstra avantaj."},
        {"title": "Beyaz Esya %10", "desc": "Buzdolabi ve camasir makinelerinde indirim."},
        {"title": "Oyun & Konsol %12", "desc": "Konsol ve oyunlarda kampanya."},
        {"title": "Spor & Outdoor %18", "desc": "Kamp ve fitness ekipmanlari."},
        {"title": "Kozmetik %25", "desc": "Cilt bakim ve parfumlerde."},
        {"title": "Gida & Market 150 TL", "desc": "1500 TL uzeri alisveriste 150 TL kupon."},
        {"title": "Evcil Hayvan %15", "desc": "Mama ve aksesuar kampanyalari."},
        {"title": "Mutfak Seti %20", "desc": "Kucuk ev aletlerinde indirim."},
        {"title": "Kitap & Kirtasiye %10", "desc": "Okul ve ofis urunlerinde."},
    ]
    campaigns = random.sample(pool, k=min(3, len(pool)))
    return render(request, "marketplace/campaigns.html", {"campaigns": campaigns})


@login_required
def seller_apply(request):
    identifier = request.user.email or request.user.username
    is_allowed = SellerAllowlist.objects.filter(identifier__iexact=identifier).exists()
    existing_request = SellerAccessRequest.objects.filter(
        user=request.user, status=SellerAccessRequest.Status.PENDING
    ).first()
    existing_store = Store.objects.filter(owner=request.user).first()
    if existing_store:
        if existing_store.status == Store.Status.SUSPENDED:
            return render(
                request,
                "marketplace/seller_apply.html",
                {"existing_store": existing_store, "store_blocked": True},
            )
        store_products = Product.objects.filter(store=existing_store).order_by("-created_at")
        return render(
            request,
            "marketplace/seller_apply.html",
            {"existing_store": existing_store, "store_products": store_products, "store_blocked": False},
        )
    if request.method == "POST":
        if is_allowed:
            form = SellerApplyForm(request.POST)
            if form.is_valid():
                with transaction.atomic():
                    store = form.save(commit=False)
                    store.owner = request.user
                    store.status = Store.Status.PENDING
                    store.save()
                    SellerProfile.objects.get_or_create(
                        user=request.user,
                        defaults={
                            "store_name": store.name,
                            "store_description": store.description,
                            "status": SellerProfile.Status.PENDING,
                        },
                    )
                    if request.user.role != User.Role.SELLER:
                        request.user.role = User.Role.SELLER
                        request.user.save(update_fields=["role"])
                return redirect("seller_apply")
        else:
            request_form = SellerAccessRequestForm(request.POST)
            if request_form.is_valid() and not existing_request:
                SellerAccessRequest.objects.create(
                    user=request.user,
                    company_name=request_form.cleaned_data["company_name"],
                    products_offered=request_form.cleaned_data["products_offered"],
                    note=request_form.cleaned_data["note"],
                )
                return redirect("seller_apply")
    form = SellerApplyForm()
    request_form = SellerAccessRequestForm()
    return render(
        request,
        "marketplace/seller_apply.html",
        {
            "form": form,
            "is_allowed": is_allowed,
            "request_form": request_form,
            "existing_request": existing_request,
        },
    )


@login_required
def seller_add_product(request):
    store = Store.objects.filter(owner=request.user).first()
    if not store:
        return redirect("seller_apply")
    if store.status != Store.Status.ACTIVE:
        return redirect("seller_apply")
    suggested_products = [
        "Akilli Telefon",
        "Bluetooth Kulaklik",
        "Robot Supurge",
        "Kahve Makinesi",
        "Camasir Makinesi",
        "Gaming Laptop",
        "Akilli Saat",
        "Tablet",
        "Akilli TV",
        "Bulasik Makinesi",
        "Airfryer",
        "Kamp Sandalyesi",
        "Kahve Degirmeni",
        "Masa Lambasi",
        "Oyuncak Seti",
        "Kalem Seti",
        "Ahşap Çalışma Masası",
        "Klasik Ayakkabı",
    ]
    suggested_categories = [
        "Elektronik",
        "Beyaz Esya",
        "Ev Eşyası",
        "Kitap",
        "Oyuncak",
        "Outdoor",
        "Moda",
        "Pet",
        "Kirtasiye",
    ]
    if request.method == "POST":
        form = ProductCreateForm(request.POST)
        if form.is_valid():
            category_name = form.cleaned_data["category"]
            category = _get_or_create_category(category_name)
            product = Product.objects.create(
                store=store,
                category=category,
                name=form.cleaned_data["name"],
                description=form.cleaned_data["description"],
                base_price=form.cleaned_data["price"],
                is_active=True,
            )
            if store.status != Store.Status.ACTIVE:
                store.status = Store.Status.ACTIVE
                store.save(update_fields=["status"])
            image_url = form.cleaned_data["image_url"]
            if image_url:
                ProductImage.objects.create(product=product, image_url=image_url, is_primary=True)
            return redirect("seller_apply")
    else:
        form = ProductCreateForm()
    return render(
        request,
        "marketplace/seller_add_product.html",
        {
            "form": form,
            "store": store,
            "suggested_products": suggested_products,
            "suggested_categories": suggested_categories,
        },
    )


@login_required
def support(request):
    return render(request, "marketplace/support.html")

# Create your views here.
