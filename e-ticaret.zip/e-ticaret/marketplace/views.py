import random
from decimal import Decimal, ROUND_HALF_UP

from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.utils.text import slugify
from django.utils.crypto import get_random_string

from accounts.models import SellerAllowlist, SellerProfile, User
from promotions.models import SellerDiscount
from .forms import ProductCreateForm, SellerApplyForm
from .models import Product, ProductImage, Store
from marketplace.models import Category


def home(request):
    _ensure_demo_products()
    products = list(
        Product.objects.select_related("store", "category")
        .prefetch_related("images", "variants")
        .filter(is_active=True)
        .order_by("-created_at")[:12]
    )
    _apply_discounts(products)
    live_stats = {
        "orders": random.randint(180, 680),
        "return_rate": f"%{random.uniform(1.2, 4.8):.1f}",
        "risky_sellers": random.randint(1, 9),
    }
    featured_demo = [
        {
            "name": "Akilli Telefon Pro",
            "category": "Elektronik",
            "price": "18.499",
            "price_value": Decimal("18499"),
            "seller": "TeknoNet",
            "image_url": "marketplace/images/phone.svg",
            "discount_percent": 10,
        },
        {
            "name": "No-Frost Buzdolabi",
            "category": "Beyaz Esya",
            "price": "24.900",
            "price_value": Decimal("24900"),
            "seller": "BeyazYap",
            "image_url": "marketplace/images/fridge.svg",
            "discount_percent": 0,
        },
        {
            "name": "Kablosuz Kulaklik",
            "category": "Elektronik",
            "price": "4.250",
            "price_value": Decimal("4250"),
            "seller": "SoundBox",
            "image_url": "marketplace/images/headphones.svg",
            "discount_percent": 15,
        },
        {
            "name": "Robot Supurge",
            "category": "Beyaz Esya",
            "price": "12.990",
            "price_value": Decimal("12990"),
            "seller": "Evim360",
            "image_url": "marketplace/images/robot-vacuum.svg",
            "discount_percent": 0,
        },
        {
            "name": "Ahcap Calisma Masasi",
            "category": "Ev Esyasi",
            "price": "3.450",
            "price_value": Decimal("3450"),
            "seller": "DekorLine",
            "image_url": "marketplace/images/desk.svg",
            "discount_percent": 20,
        },
        {
            "name": "Vintage Kitap Seti",
            "category": "Kitap",
            "price": "850",
            "price_value": Decimal("850"),
            "seller": "KampusKitap",
            "image_url": "marketplace/images/books.svg",
            "discount_percent": 0,
        },
        {
            "name": "Ergonomik Sandalye",
            "category": "Ev Esyasi",
            "price": "2.700",
            "price_value": Decimal("2700"),
            "seller": "DekorLine",
            "image_url": "marketplace/images/chair.svg",
            "discount_percent": 5,
        },
        {
            "name": "Koleksiyon Oyuncak",
            "category": "Oyuncak",
            "price": "1.150",
            "price_value": Decimal("1150"),
            "seller": "ToyBox",
            "image_url": "marketplace/images/toy.svg",
            "discount_percent": 0,
        },
    ]
    for item in featured_demo:
        if item["discount_percent"]:
            discounted = _apply_discount_price(item["price_value"], item["discount_percent"])
            item["discounted_price"] = f"{discounted:,.2f}".replace(",", ".")
        else:
            item["discounted_price"] = ""
    context = {
        "products": products,
        "live_stats": live_stats,
        "featured_demo": featured_demo,
    }
    return render(request, "marketplace/home.html", context)


def _apply_discount_price(price: Decimal, percent: int) -> Decimal:
    return (price * (Decimal("100") - Decimal(percent)) / Decimal("100")).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )


def _apply_discounts(products: list[Product]) -> None:
    if not products:
        return
    now = timezone.now()
    store_ids = {product.store_id for product in products}
    product_ids = {product.id for product in products}
    discounts = SellerDiscount.objects.filter(
        starts_at__lte=now,
        ends_at__gte=now,
    ).filter(Q(product_id__in=product_ids) | Q(product__isnull=True, store_id__in=store_ids))
    product_discounts: dict[int, int] = {}
    store_discounts: dict[int, int] = {}
    for discount in discounts:
        if discount.product_id:
            product_discounts[discount.product_id] = max(
                product_discounts.get(discount.product_id, 0), discount.percent
            )
        else:
            store_discounts[discount.store_id] = max(
                store_discounts.get(discount.store_id, 0), discount.percent
            )
    for product in products:
        percent = product_discounts.get(product.id) or store_discounts.get(product.store_id, 0)
        product.discount_percent = percent
        if percent:
            product.discounted_price = _apply_discount_price(product.base_price, percent)
        else:
            product.discounted_price = None


def _get_or_create_category(name: str) -> Category:
    base_slug = slugify(name)
    if not base_slug:
        base_slug = get_random_string(6)
    category = Category.objects.filter(slug=base_slug).first()
    if category:
        return category
    try:
        return Category.objects.create(name=name, slug=base_slug)
    except Exception:
        unique_slug = f"{base_slug}-{get_random_string(4)}"
        return Category.objects.create(name=name, slug=unique_slug)


def _ensure_demo_products() -> None:
    if Product.objects.exists():
        return
    demo_seller, _created = User.objects.get_or_create(
        username="demo_seller",
        defaults={"role": User.Role.SELLER},
    )
    store, _created = Store.objects.get_or_create(
        owner=demo_seller,
        name="Demo Magaza",
        defaults={
            "description": "Demo urunler icin ornek magaza.",
            "status": Store.Status.ACTIVE,
        },
    )
    demo_items = [
        ("Akilli Telefon Pro", "Elektronik", Decimal("18499"), "marketplace/images/phone.svg"),
        ("No-Frost Buzdolabi", "Beyaz Esya", Decimal("24900"), "marketplace/images/fridge.svg"),
        ("Kablosuz Kulaklik", "Elektronik", Decimal("4250"), "marketplace/images/headphones.svg"),
        ("Robot Supurge", "Beyaz Esya", Decimal("12990"), "marketplace/images/robot-vacuum.svg"),
        ("Ahcap Calisma Masasi", "Ev Esyasi", Decimal("3450"), "marketplace/images/desk.svg"),
        ("Vintage Kitap Seti", "Kitap", Decimal("850"), "marketplace/images/books.svg"),
        ("Ergonomik Sandalye", "Ev Esyasi", Decimal("2700"), "marketplace/images/chair.svg"),
        ("Koleksiyon Oyuncak", "Oyuncak", Decimal("1150"), "marketplace/images/toy.svg"),
    ]
    for name, category_name, price, image_url in demo_items:
        category = _get_or_create_category(category_name)
        product, created = Product.objects.get_or_create(
            store=store,
            name=name,
            defaults={
                "category": category,
                "description": f"{name} icin demo aciklama.",
                "base_price": price,
                "is_active": True,
            },
        )
        if created:
            ProductImage.objects.create(product=product, image_url=f"/static/{image_url}", is_primary=True)


def catalog(request):
    query = request.GET.get("q", "").strip()
    selected_category = request.GET.get("category", "").strip()
    sort = request.GET.get("sort", "new").strip()
    _ensure_demo_products()
    products = list(
        Product.objects.select_related("store", "category")
        .prefetch_related("images", "variants")
        .filter(is_active=True)
    )
    if query:
        products = [product for product in products if query.lower() in product.name.lower()]
    if selected_category:
        products = [product for product in products if product.category and product.category.slug == selected_category]
    if sort == "price_asc":
        products = sorted(products, key=lambda p: p.base_price)
    elif sort == "price_desc":
        products = sorted(products, key=lambda p: p.base_price, reverse=True)
    else:
        products = sorted(products, key=lambda p: p.created_at, reverse=True)
    _apply_discounts(products)
    demo_items = [
        {
            "name": "Akilli Telefon Pro",
            "category": "Elektronik",
            "price": "18.499",
            "price_value": Decimal("18499"),
            "seller": "TeknoNet",
            "image_class": "media-electronics",
            "image_url": "marketplace/images/phone.svg",
            "discount_percent": 10,
        },
        {
            "name": "No-Frost Buzdolabi",
            "category": "Beyaz Esya",
            "price": "24.900",
            "price_value": Decimal("24900"),
            "seller": "BeyazYap",
            "image_class": "media-whitegoods",
            "image_url": "marketplace/images/fridge.svg",
            "discount_percent": 0,
        },
        {
            "name": "Kablosuz Kulaklik",
            "category": "Elektronik",
            "price": "4.250",
            "price_value": Decimal("4250"),
            "seller": "SoundBox",
            "image_class": "media-electronics",
            "image_url": "marketplace/images/headphones.svg",
            "discount_percent": 15,
        },
        {
            "name": "Robot Supurge",
            "category": "Beyaz Esya",
            "price": "12.990",
            "price_value": Decimal("12990"),
            "seller": "Evim360",
            "image_class": "media-whitegoods",
            "image_url": "marketplace/images/robot-vacuum.svg",
            "discount_percent": 0,
        },
        {
            "name": "Ahcap Calisma Masasi",
            "category": "Ev Esyasi",
            "price": "3.450",
            "price_value": Decimal("3450"),
            "seller": "DekorLine",
            "image_class": "media-home",
            "image_url": "marketplace/images/desk.svg",
            "discount_percent": 20,
        },
        {
            "name": "Vintage Kitap Seti",
            "category": "Kitap",
            "price": "850",
            "price_value": Decimal("850"),
            "seller": "KampusKitap",
            "image_class": "media-books",
            "image_url": "marketplace/images/books.svg",
            "discount_percent": 0,
        },
        {
            "name": "Ergonomik Sandalye",
            "category": "Ev Esyasi",
            "price": "2.700",
            "price_value": Decimal("2700"),
            "seller": "DekorLine",
            "image_class": "media-home",
            "image_url": "marketplace/images/chair.svg",
            "discount_percent": 5,
        },
        {
            "name": "Koleksiyon Oyuncak",
            "category": "Oyuncak",
            "price": "1.150",
            "price_value": Decimal("1150"),
            "seller": "ToyBox",
            "image_class": "media-toys",
            "image_url": "marketplace/images/toy.svg",
            "discount_percent": 0,
        },
        {
            "name": "Gaming Laptop 16",
            "category": "Elektronik",
            "price": "42.900",
            "price_value": Decimal("42900"),
            "seller": "GameTek",
            "image_class": "media-electronics",
            "image_url": "marketplace/images/laptop.svg",
            "discount_percent": 8,
        },
        {
            "name": "Akilli Saat X",
            "category": "Elektronik",
            "price": "7.990",
            "price_value": Decimal("7990"),
            "seller": "PulseWear",
            "image_class": "media-electronics",
            "image_url": "marketplace/images/smartwatch.svg",
            "discount_percent": 0,
        },
        {
            "name": "Camasir Makinesi 9kg",
            "category": "Beyaz Esya",
            "price": "19.800",
            "price_value": Decimal("19800"),
            "seller": "BeyazYap",
            "image_class": "media-whitegoods",
            "image_url": "marketplace/images/washing-machine.svg",
            "discount_percent": 12,
        },
        {
            "name": "Kahve Makinesi",
            "category": "Ev Esyasi",
            "price": "2.150",
            "price_value": Decimal("2150"),
            "seller": "KahveLab",
            "image_class": "media-home",
            "image_url": "marketplace/images/coffee-machine.svg",
            "discount_percent": 0,
        },
        {
            "name": "Kamp Termosu",
            "category": "Outdoor",
            "price": "780",
            "price_value": Decimal("780"),
            "seller": "Outdoorist",
            "image_class": "media-home",
            "image_url": "marketplace/images/thermos.svg",
            "discount_percent": 0,
        },
        {
            "name": "Akilli TV 55\"",
            "category": "Elektronik",
            "price": "28.500",
            "price_value": Decimal("28500"),
            "seller": "TeknoNet",
            "image_class": "media-electronics",
            "image_url": "marketplace/images/tv.svg",
            "discount_percent": 10,
        },
        {
            "name": "Airfryer 5L",
            "category": "Beyaz Esya",
            "price": "3.900",
            "price_value": Decimal("3900"),
            "seller": "MutfakPro",
            "image_class": "media-whitegoods",
            "image_url": "marketplace/images/airfryer.svg",
            "discount_percent": 0,
        },
    ]
    for item in demo_items:
        if item["discount_percent"]:
            discounted = _apply_discount_price(item["price_value"], item["discount_percent"])
            item["discounted_price"] = f"{discounted:,.2f}".replace(",", ".")
        else:
            item["discounted_price"] = ""
    use_demo = not products
    demo_categories = sorted({item["category"] for item in demo_items})
    if use_demo:
        if query:
            demo_items = [item for item in demo_items if query.lower() in item["name"].lower()]
        if selected_category:
            demo_items = [item for item in demo_items if item["category"] == selected_category]
    categories = Category.objects.filter(is_active=True).order_by("name")
    return render(
        request,
        "marketplace/catalog.html",
        {
            "products": products,
            "demo_items": demo_items,
            "use_demo": use_demo,
            "categories": categories,
            "demo_categories": demo_categories,
            "query": query,
            "selected_category": selected_category,
            "sort": sort,
        },
    )


def sellers(request):
    stores = (
        Product.objects.select_related("store")
        .filter(is_active=True, store__status="ACTIVE")
        .values("store__id", "store__name", "store__description")
        .distinct()
        .order_by("store__name")
    )
    demo_names = [
        "KuzeyTech",
        "AnadoluCasa",
        "MaviKutu",
        "PeraDesign",
        "SahilMarket",
        "NovaHome",
        "ZenitStore",
        "EfsunModa",
        "ArvenShop",
        "AtlasPlus",
    ]
    demo_desc = [
        "Elektronik ve ev teknolojilerinde garantili urunler.",
        "Ev esyasi ve dekorasyon odakli yeni koleksiyonlar.",
        "Kucuk mutfak aletleri ve gunluk ihtiyaclar.",
        "Sade tasarimli mobilya ve aksesuar secimleri.",
        "Kampanyali gunluk urunler ve hizli kargo.",
        "Beyaz esyada premium secenekler.",
        "Minimalist ve fonksiyonel urunler.",
        "Moda ve yasam stili odakli secili urunler.",
    ]
    demo_sellers = []
    for name in random.sample(demo_names, k=6):
        demo_sellers.append(
            {
                "name": name,
                "description": random.choice(demo_desc),
            }
        )
    return render(
        request,
        "marketplace/sellers.html",
        {"stores": stores, "demo_sellers": demo_sellers},
    )


def product_detail(request, product_id: int):
    product = get_object_or_404(
        Product.objects.select_related("store", "category").prefetch_related("images", "variants"),
        id=product_id,
        is_active=True,
    )
    return render(request, "marketplace/product_detail.html", {"product": product})


def _is_admin(user: User) -> bool:
    return user.is_authenticated and (user.is_staff or user.role == User.Role.ADMIN)


@login_required
def admin_panel(request):
    if not _is_admin(request.user):
        return redirect("home")
    pending_stores = Store.objects.filter(status=Store.Status.PENDING).select_related("owner")
    return render(request, "marketplace/admin_panel.html", {"pending_stores": pending_stores})


@login_required
def approve_seller(request, store_id: int):
    if request.method != "POST" or not _is_admin(request.user):
        return redirect("home")
    store = get_object_or_404(Store, id=store_id)
    store.status = Store.Status.ACTIVE
    store.save(update_fields=["status"])
    SellerProfile.objects.update_or_create(
        user=store.owner,
        defaults={
            "store_name": store.name,
            "store_description": store.description,
            "status": SellerProfile.Status.APPROVED,
        },
    )
    return redirect("admin_panel")


@login_required
def reject_seller(request, store_id: int):
    if request.method != "POST" or not _is_admin(request.user):
        return redirect("home")
    store = get_object_or_404(Store, id=store_id)
    store.status = Store.Status.REJECTED
    store.save(update_fields=["status"])
    SellerProfile.objects.update_or_create(
        user=store.owner,
        defaults={
            "store_name": store.name,
            "store_description": store.description,
            "status": SellerProfile.Status.REJECTED,
        },
    )
    return redirect("admin_panel")


@login_required
def categories(request):
    return render(request, "marketplace/categories.html")


@login_required
def campaigns(request):
    return render(request, "marketplace/campaigns.html")


@login_required
def seller_apply(request):
    identifier = request.user.email or request.user.username
    is_allowed = SellerAllowlist.objects.filter(identifier__iexact=identifier).exists()
    existing_store = Store.objects.filter(owner=request.user).first()
    if existing_store:
        return render(
            request,
            "marketplace/seller_apply.html",
            {"existing_store": existing_store},
        )
    if request.method == "POST" and is_allowed:
        form = SellerApplyForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                store = form.save(commit=False)
                store.owner = request.user
                store.status = Store.Status.PENDING
                store.save()
                SellerProfile.objects.get_or_create(
                    user=request.user,
                    defaults={
                        "store_name": store.name,
                        "store_description": store.description,
                        "status": SellerProfile.Status.PENDING,
                    },
                )
                if request.user.role != User.Role.SELLER:
                    request.user.role = User.Role.SELLER
                    request.user.save(update_fields=["role"])
            return redirect("seller_apply")
    else:
        form = SellerApplyForm()
    return render(
        request,
        "marketplace/seller_apply.html",
        {"form": form, "is_allowed": is_allowed},
    )


@login_required
def seller_add_product(request):
    store = Store.objects.filter(owner=request.user).first()
    if not store:
        return redirect("seller_apply")
    suggested_products = [
        "Akilli Telefon",
        "Bluetooth Kulaklik",
        "Robot Supurge",
        "Kahve Makinesi",
        "Camasir Makinesi",
        "Gaming Laptop",
    ]
    suggested_categories = [
        "Elektronik",
        "Beyaz Esya",
        "Ev Esyasi",
        "Kitap",
        "Oyuncak",
        "Outdoor",
    ]
    if request.method == "POST":
        form = ProductCreateForm(request.POST)
        if form.is_valid():
            category_name = form.cleaned_data["category"]
            category = _get_or_create_category(category_name)
            product = Product.objects.create(
                store=store,
                category=category,
                name=form.cleaned_data["name"],
                description=form.cleaned_data["description"],
                base_price=form.cleaned_data["price"],
                is_active=True,
            )
            image_url = form.cleaned_data["image_url"]
            if image_url:
                ProductImage.objects.create(product=product, image_url=image_url, is_primary=True)
            return redirect("seller_apply")
    else:
        form = ProductCreateForm()
    return render(
        request,
        "marketplace/seller_add_product.html",
        {
            "form": form,
            "store": store,
            "suggested_products": suggested_products,
            "suggested_categories": suggested_categories,
        },
    )


@login_required
def support(request):
    return render(request, "marketplace/support.html")

# Create your views here.
