from django.contrib import admin

from .models import (
    Category,
    Product,
    ProductBundleItem,
    ProductImage,
    ProductVariant,
    Store,
    StoreUpdateRequest,
)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "is_active")
    search_fields = ("name", "slug")


@admin.register(Store)
class StoreAdmin(admin.ModelAdmin):
    list_display = ("name", "owner", "status", "updated_at")
    list_filter = ("status",)
    search_fields = ("name", "owner__username")


@admin.register(StoreUpdateRequest)
class StoreUpdateRequestAdmin(admin.ModelAdmin):
    list_display = ("store", "requested_by", "status", "reviewed_at")
    list_filter = ("status",)


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "store", "category", "base_price", "is_active", "is_preorder", "is_bundle")
    list_filter = ("is_active", "is_preorder", "is_bundle")
    search_fields = ("name", "store__name")


@admin.register(ProductVariant)
class ProductVariantAdmin(admin.ModelAdmin):
    list_display = ("product", "name", "sku", "price", "stock", "reserved_stock")
    search_fields = ("sku",)


@admin.register(ProductImage)
class ProductImageAdmin(admin.ModelAdmin):
    list_display = ("product", "image_url", "is_primary")


@admin.register(ProductBundleItem)
class ProductBundleItemAdmin(admin.ModelAdmin):
    list_display = ("bundle", "item", "quantity")

# Register your models here.
