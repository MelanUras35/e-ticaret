from django.apps import AppConfig


class DisputesConfig(AppConfig):
    name = 'disputes'
