from django.urls import path

from . import views

urlpatterns = [
    path("sepetim/", views.cart_view, name="cart"),
    path("sepet/ekle/", views.add_to_cart, name="add_to_cart"),
    path("sepet/sil/<int:item_id>/", views.remove_from_cart, name="remove_from_cart"),
    path("sepet/guncelle/<int:item_id>/", views.update_quantity, name="update_quantity"),
    path("sepet/odeme/", views.checkout, name="checkout"),
]
