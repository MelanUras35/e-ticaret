from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render

from marketplace.models import Product

from .models import Cart, CartItem, Order, OrderItem


@login_required
def cart_view(request):
    cart, _created = Cart.objects.get_or_create(user=request.user)
    cart_items = cart.items.select_related("product", "variant")
    purchased_items = (
        OrderItem.objects.select_related("order", "product")
        .filter(order__buyer=request.user)
        .order_by("-order__created_at")[:10]
    )
    total = sum(item.unit_price * item.quantity for item in cart_items)
    context = {
        "cart_items": cart_items,
        "purchased_items": purchased_items,
        "total": total,
    }
    return render(request, "orders/cart.html", context)


@login_required
def add_to_cart(request):
    if request.method != "POST":
        return redirect("catalog")
    product = get_object_or_404(Product, id=request.POST.get("product_id"))
    cart, _created = Cart.objects.get_or_create(user=request.user)
    item, created = CartItem.objects.get_or_create(
        cart=cart,
        product=product,
        defaults={"quantity": 1, "unit_price": product.base_price},
    )
    if not created:
        item.quantity += 1
        item.unit_price = product.base_price
        item.save(update_fields=["quantity", "unit_price"])
    return redirect("cart")


@login_required
def remove_from_cart(request, item_id: int):
    if request.method != "POST":
        return redirect("cart")
    cart = get_object_or_404(Cart, user=request.user)
    CartItem.objects.filter(cart=cart, id=item_id).delete()
    return redirect("cart")


@login_required
def update_quantity(request, item_id: int):
    if request.method != "POST":
        return redirect("cart")
    cart = get_object_or_404(Cart, user=request.user)
    item = get_object_or_404(CartItem, cart=cart, id=item_id)
    try:
        quantity = int(request.POST.get("quantity", item.quantity))
    except ValueError:
        quantity = item.quantity
    if quantity <= 0:
        item.delete()
    else:
        item.quantity = min(quantity, 99)
        item.save(update_fields=["quantity"])
    return redirect("cart")


@login_required
def checkout(request):
    if request.method != "POST":
        return redirect("cart")
    cart = get_object_or_404(Cart, user=request.user)
    cart_items = list(cart.items.select_related("product"))
    if not cart_items:
        return redirect("cart")
    with transaction.atomic():
        total = sum(item.unit_price * item.quantity for item in cart_items)
        order = Order.objects.create(buyer=request.user, status=Order.Status.PAID, total=total)
        for item in cart_items:
            OrderItem.objects.create(
                order=order,
                seller=item.product.store,
                product=item.product,
                variant=item.variant,
                quantity=item.quantity,
                unit_price=item.unit_price,
                status=OrderItem.Status.PREPARING,
            )
        cart.items.all().delete()
    return redirect("cart")
