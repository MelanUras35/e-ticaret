from django.contrib import admin

from .models import Cart, CartItem, Order, OrderItem, Payment, ReturnRequest, Shipment, StockReservation


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "buyer", "status", "total", "created_at")
    list_filter = ("status",)
    search_fields = ("buyer__username",)


@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ("order", "seller", "product", "quantity", "status")
    list_filter = ("status",)


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("order", "status", "amount", "provider", "paid_at")
    list_filter = ("status",)


@admin.register(Shipment)
class ShipmentAdmin(admin.ModelAdmin):
    list_display = ("order", "seller", "tracking_number", "status", "shipped_at", "delivered_at")
    list_filter = ("status",)


@admin.register(StockReservation)
class StockReservationAdmin(admin.ModelAdmin):
    list_display = ("variant", "order_item", "quantity", "reserved_until")


@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ("user", "updated_at")


@admin.register(CartItem)
class CartItemAdmin(admin.ModelAdmin):
    list_display = ("cart", "product", "variant", "quantity", "unit_price")


@admin.register(ReturnRequest)
class ReturnRequestAdmin(admin.ModelAdmin):
    list_display = ("order_item", "request_type", "status", "created_at")
    list_filter = ("request_type", "status")

# Register your models here.
