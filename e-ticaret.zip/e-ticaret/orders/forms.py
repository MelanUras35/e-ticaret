from django import forms


class OrderCheckoutForm(forms.Form):
    address = forms.CharField(label="Adres", widget=forms.Textarea(attrs={"rows": 3}))
    phone = forms.CharField(label="Telefon", max_length=32)
    card_number = forms.CharField(label="Kart Numarasi", max_length=19)

    def clean_card_number(self):
        value = self.cleaned_data["card_number"].replace(" ", "")
        if not value.isdigit():
            raise forms.ValidationError("Kart numarasi sadece rakam icermeli.")
        if len(value) < 12:
            raise forms.ValidationError("Kart numarasi gecersiz.")
        return value
