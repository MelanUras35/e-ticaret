# 3 Rollu E-Ticaret Platformu (Django)

Bu proje, admin / satici / alici rollerini kapsayan cok saticili e-ticaret senaryolari icin Django tabanli bir domain iskeleti saglar.

## Kurulum

```powershell
python -m venv .venv
.\\.venv\\Scripts\\Activate.ps1
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

## Moduller

- accounts: Rol bazli kullanici, satici onboarding, risk bayraklari.
- marketplace: Magaza, kategori, urun, varyant, bundle, kisitli urun.
- orders: Sepet/siparis, odeme, kargo, stok rezervasyon, iade/iptal.
- messaging: Siparis bazli mesajlasma ve moderasyon.
- reviews: Yorum/puanlama ve admin moderasyonu.
- disputes: Sikayet/dispute ve admin karari.
- promotions: Satici indirimi ve admin kuponu.
- reports: Admin/satici/alici rapor snapshot'lari.
