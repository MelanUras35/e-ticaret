from django.db import models

from accounts.models import User
from marketplace.models import Product, Store
from orders.models import Order


class Coupon(models.Model):
    class DiscountType(models.TextChoices):
        PERCENT = "PERCENT", "Percent"
        FIXED = "FIXED", "Fixed"

    code = models.CharField(max_length=40, unique=True)
    discount_type = models.CharField(max_length=16, choices=DiscountType.choices)
    value = models.DecimalField(max_digits=10, decimal_places=2)
    min_cart_total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField()
    is_admin = models.BooleanField(default=False)
    is_stackable = models.BooleanField(default=False)
    max_uses = models.PositiveIntegerField(default=0)
    per_user_limit = models.PositiveIntegerField(default=0)
    uses = models.PositiveIntegerField(default=0)

    def __str__(self) -> str:
        return self.code


class CouponRedemption(models.Model):
    coupon = models.ForeignKey(Coupon, on_delete=models.CASCADE, related_name="redemptions")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="coupon_redemptions")
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="coupon_redemptions")
    redeemed_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f"{self.coupon.code} by {self.user.username}"


class SellerDiscount(models.Model):
    store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name="discounts")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="discounts", null=True, blank=True)
    percent = models.PositiveIntegerField()
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField()

    def __str__(self) -> str:
        return f"{self.percent}% discount for {self.store.name}"

# Create your models here.
