from django.contrib import admin

from .models import Coupon, CouponRedemption, SellerDiscount


@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = ("code", "discount_type", "value", "min_cart_total", "is_admin", "is_stackable")
    list_filter = ("discount_type", "is_admin", "is_stackable")
    search_fields = ("code",)


@admin.register(CouponRedemption)
class CouponRedemptionAdmin(admin.ModelAdmin):
    list_display = ("coupon", "user", "order", "redeemed_at")


@admin.register(SellerDiscount)
class SellerDiscountAdmin(admin.ModelAdmin):
    list_display = ("store", "product", "percent", "starts_at", "ends_at")

# Register your models here.
