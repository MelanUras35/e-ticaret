from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = "ADMIN", "Admin"
        SELLER = "SELLER", "Seller"
        BUYER = "BUYER", "Buyer"

    role = models.CharField(max_length=16, choices=Role.choices, default=Role.BUYER)
    phone = models.CharField(max_length=32, blank=True)
    is_risky_buyer = models.BooleanField(default=False)
    is_risky_seller = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f"{self.username} ({self.role})"


class SellerProfile(models.Model):
    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        SUSPENDED = "SUSPENDED", "Suspended"
        UNDER_REVIEW = "UNDER_REVIEW", "Under review"
        REJECTED = "REJECTED", "Rejected"

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="seller_profile")
    store_name = models.CharField(max_length=150)
    store_description = models.TextField(blank=True)
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.PENDING)
    last_reviewed_at = models.DateTimeField(null=True, blank=True)
    suspended_reason = models.TextField(blank=True)

    def mark_reviewed(self, status: str) -> None:
        self.status = status
        self.last_reviewed_at = timezone.now()
        self.save(update_fields=["status", "last_reviewed_at"])

    def __str__(self) -> str:
        return f"{self.store_name} ({self.get_status_display()})"


class SellerWarning(models.Model):
    seller = models.ForeignKey(User, on_delete=models.CASCADE, related_name="warnings")
    message = models.TextField()
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="issued_warnings")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f"Warning for {self.seller.username}"


class BuyerProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="buyer_profile")
    risk_notes = models.TextField(blank=True)
    total_spent = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def __str__(self) -> str:
        return self.user.username


class SellerAllowlist(models.Model):
    identifier = models.CharField(max_length=150, unique=True)
    note = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return self.identifier

# Create your models here.
