from django.urls import path

from . import views

urlpatterns = [
    path("giris/", views.login_view, name="login"),
    path("kayit/", views.register_view, name="register"),
    path("cikis/", views.logout_view, name="logout"),
]
