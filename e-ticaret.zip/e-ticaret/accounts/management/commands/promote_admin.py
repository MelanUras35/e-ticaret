from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = "Promote a user to admin (staff + superuser) and set password if provided."

    def add_arguments(self, parser):
        parser.add_argument("username", type=str)
        parser.add_argument("--password", type=str, default="")

    def handle(self, *args, **options):
        username = options["username"]
        password = options["password"]
        user_model = get_user_model()
        try:
            user = user_model.objects.get(username=username)
        except user_model.DoesNotExist as exc:
            raise CommandError("Kullanici bulunamadi.") from exc
        user.is_staff = True
        user.is_superuser = True
        if hasattr(user, "role") and hasattr(user_model, "Role"):
            user.role = user_model.Role.ADMIN
        if password:
            user.set_password(password)
        user.save()
        self.stdout.write(self.style.SUCCESS("Kullanici admin yapildi."))
