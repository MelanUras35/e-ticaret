from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin

from .models import BuyerProfile, SellerAllowlist, SellerProfile, SellerWarning, User


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    fieldsets = DjangoUserAdmin.fieldsets + (
        ("Role & Risk", {"fields": ("role", "phone", "is_risky_buyer", "is_risky_seller")}),
    )
    list_display = ("username", "email", "role", "is_risky_buyer", "is_risky_seller", "is_staff")
    list_filter = ("role", "is_risky_buyer", "is_risky_seller", "is_staff")


@admin.register(SellerProfile)
class SellerProfileAdmin(admin.ModelAdmin):
    list_display = ("store_name", "user", "status", "last_reviewed_at")
    list_filter = ("status",)
    search_fields = ("store_name", "user__username")


@admin.register(SellerWarning)
class SellerWarningAdmin(admin.ModelAdmin):
    list_display = ("seller", "created_by", "created_at")
    search_fields = ("seller__username",)


@admin.register(BuyerProfile)
class BuyerProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "total_spent")


@admin.register(SellerAllowlist)
class SellerAllowlistAdmin(admin.ModelAdmin):
    list_display = ("identifier", "note", "created_at")
    search_fields = ("identifier",)

# Register your models here.
