from django.db import models

from accounts.models import User


class ReportSnapshot(models.Model):
    class ReportType(models.TextChoices):
        ADMIN_SALES = "ADMIN_SALES", "Admin sales"
        ADMIN_RETURNS = "ADMIN_RETURNS", "Admin returns"
        SELLER_WEEKLY = "SELLER_WEEKLY", "Seller weekly"
        BUYER_HISTORY = "BUYER_HISTORY", "Buyer history"

    report_type = models.CharField(max_length=24, choices=ReportType.choices)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="reports")
    payload = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f"{self.report_type} for {self.owner.username}"

# Create your models here.
