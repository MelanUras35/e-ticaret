from django.db import models

from accounts.models import User
from marketplace.models import Product, Store


class ReportSnapshot(models.Model):
    class ReportType(models.TextChoices):
        ADMIN_SALES = "ADMIN_SALES", "Admin sales"
        ADMIN_RETURNS = "ADMIN_RETURNS", "Admin returns"
        SELLER_WEEKLY = "SELLER_WEEKLY", "Seller weekly"
        BUYER_HISTORY = "BUYER_HISTORY", "Buyer history"

    report_type = models.CharField(max_length=24, choices=ReportType.choices)
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="reports")
    payload = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f"{self.report_type} for {self.owner.username}"


class UserReport(models.Model):
    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        ACCEPTED = "ACCEPTED", "Accepted"
        REJECTED = "REJECTED", "Rejected"

    class Reason(models.TextChoices):
        ILLEGAL = "ILLEGAL", "Illegal items"
        FRAUD = "FRAUD", "Fraud / Scam"
        HARASSMENT = "HARASSMENT", "Harassment"
        SPAM = "SPAM", "Spam"
        OTHER = "OTHER", "Other"

    reporter = models.ForeignKey(User, on_delete=models.CASCADE, related_name="reports_sent")
    reported_user = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name="reports_received"
    )
    reported_store = models.ForeignKey(
        Store, on_delete=models.SET_NULL, null=True, blank=True, related_name="reports_received"
    )
    reported_product = models.ForeignKey(
        Product, on_delete=models.SET_NULL, null=True, blank=True, related_name="reports_received"
    )
    reason = models.CharField(max_length=24, choices=Reason.choices)
    description = models.TextField()
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.PENDING)
    admin_note = models.TextField(blank=True)
    reviewed_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name="reports_reviewed"
    )
    reviewed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f"Report #{self.id} by {self.reporter.username}"

    @property
    def target_label(self) -> str:
        if self.reported_product:
            store_name = self.reported_product.store.name if self.reported_product.store_id else "-"
            return f"Product: {self.reported_product.name} (Store: {store_name})"
        if self.reported_store:
            return f"Store: {self.reported_store.name}"
        if self.reported_user:
            return f"User: {self.reported_user.username}"
        return "Unknown"

# Create your models here.
