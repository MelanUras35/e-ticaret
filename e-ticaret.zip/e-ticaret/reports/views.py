from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from accounts.models import SellerProfile, User
from marketplace.models import Product, Store

from .forms import UserReportForm
from .models import UserReport


def _is_admin(user: User) -> bool:
    return user.is_authenticated and (user.is_staff or user.role == User.Role.ADMIN)


@login_required
def report_create(request):
    initial = {}
    if request.GET.get("user"):
        initial["reported_user"] = request.GET.get("user")
    if request.GET.get("store"):
        initial["reported_store"] = request.GET.get("store")
    if request.GET.get("product"):
        initial["reported_product"] = request.GET.get("product")

    if request.method == "POST":
        form = UserReportForm(request.POST, reporter=request.user)
        if form.is_valid():
            report = form.save(commit=False)
            report.reporter = request.user
            report.save()
            return redirect(f"{request.path}?submitted=1")
    else:
        form = UserReportForm(reporter=request.user, initial=initial)

    return render(request, "reports/report_create.html", {"form": form, "submitted": request.GET.get("submitted")})


@login_required
def approve_report(request, report_id: int):
    if request.method != "POST" or not _is_admin(request.user):
        return redirect("home")
    report = get_object_or_404(UserReport, id=report_id)
    report.status = UserReport.Status.ACCEPTED
    report.reviewed_by = request.user
    report.reviewed_at = timezone.now()
    report.save(update_fields=["status", "reviewed_by", "reviewed_at"])
    _apply_report_penalty(report)
    return redirect("admin_panel")


@login_required
def reject_report(request, report_id: int):
    if request.method != "POST" or not _is_admin(request.user):
        return redirect("home")
    report = get_object_or_404(UserReport, id=report_id)
    report.status = UserReport.Status.REJECTED
    report.reviewed_by = request.user
    report.reviewed_at = timezone.now()
    report.save(update_fields=["status", "reviewed_by", "reviewed_at"])
    return redirect("admin_panel")


def _apply_report_penalty(report: UserReport) -> None:
    store_targets = []
    if report.reported_product and report.reported_product.store_id:
        store_targets.append(report.reported_product.store)
    if report.reported_store:
        store_targets.append(report.reported_store)
    if report.reported_user:
        store_targets.extend(Store.objects.filter(owner=report.reported_user))
    if not store_targets:
        return

    for store in store_targets:
        store.status = Store.Status.SUSPENDED
        store.save(update_fields=["status"])
        Product.objects.filter(store=store).update(is_active=False)
        SellerProfile.objects.update_or_create(
            user=store.owner,
            defaults={
                "store_name": store.name,
                "store_description": store.description,
                "status": SellerProfile.Status.SUSPENDED,
                "suspended_reason": "Rapor onayi ile kapatildi.",
            },
        )
