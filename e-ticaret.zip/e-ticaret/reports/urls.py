from django.urls import path

from . import views

urlpatterns = [
    path("raporla/", views.report_create, name="report_create"),
    path("yonetim/rapor/<int:report_id>/onay/", views.approve_report, name="approve_report"),
    path("yonetim/rapor/<int:report_id>/red/", views.reject_report, name="reject_report"),
]
