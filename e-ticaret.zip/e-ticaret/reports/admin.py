from django.contrib import admin

from .models import ReportSnapshot, UserReport


@admin.register(ReportSnapshot)
class ReportSnapshotAdmin(admin.ModelAdmin):
    list_display = ("report_type", "owner", "created_at")
    list_filter = ("report_type",)

@admin.register(UserReport)
class UserReportAdmin(admin.ModelAdmin):
    list_display = ("id", "status", "reason", "reporter", "reported_user", "reported_store", "reported_product", "created_at")
    list_filter = ("status", "reason")
    search_fields = ("reporter__username", "reported_user__username", "reported_store__name", "reported_product__name")
