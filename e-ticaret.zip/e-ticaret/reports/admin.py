from django.contrib import admin

from .models import ReportSnapshot


@admin.register(ReportSnapshot)
class ReportSnapshotAdmin(admin.ModelAdmin):
    list_display = ("report_type", "owner", "created_at")
    list_filter = ("report_type",)

# Register your models here.
