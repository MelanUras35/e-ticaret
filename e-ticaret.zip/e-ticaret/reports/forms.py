from django import forms

from accounts.models import User
from marketplace.models import Product, Store

from .models import UserReport


class UserReportForm(forms.ModelForm):
    class Meta:
        model = UserReport
        fields = ("reported_user", "reported_store", "reported_product", "reason", "description")
        widgets = {
            "description": forms.Textarea(attrs={"rows": 4}),
        }

    def __init__(self, *args, reporter=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["reported_user"].queryset = (
            User.objects.exclude(id=reporter.id).order_by("username") if reporter else User.objects.order_by("username")
        )
        self.fields["reported_store"].queryset = Store.objects.order_by("name")
        self.fields["reported_product"].queryset = Product.objects.select_related("store").order_by("name")
        self.fields["reported_user"].empty_label = "Seciniz (opsiyonel)"
        self.fields["reported_store"].empty_label = "Seciniz (opsiyonel)"
        self.fields["reported_product"].empty_label = "Seciniz (opsiyonel)"

    def clean(self):
        cleaned = super().clean()
        if not (cleaned.get("reported_user") or cleaned.get("reported_store") or cleaned.get("reported_product")):
            raise forms.ValidationError("Lutfen raporlanacak kisi, magaza veya urun secin.")
        return cleaned
